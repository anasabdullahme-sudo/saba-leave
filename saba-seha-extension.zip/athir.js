// أثير (saba.athir.net): لما الموظف يختار طبيب في «كشف جديد» يطلع جنب خانة الطبيب: الدور، العيادة، التحويلة، وحالته الحين
(() => {
  if (window.top !== window && !document.querySelector("select")) return;
  const URL_BASE = "https://firestore.googleapis.com/v1/projects/saba-leave/databases/(default)/documents/board/";
  const WD = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
  const FLOOR_DEF = { B: "عيادة التجميل (بيوتي)", G: "الدور الأرضي", 1: "الدور الأول", 2: "الدور الثاني", 3: "الدور الثالث", 4: "الدور الرابع", 5: "الدور الخامس" };
  let board = null, today = null, lastFetch = 0, host = null, box = null, field = null, lastSig = "";

  /* ---------- البيانات (جدول البوادي — قراءة عامة) ---------- */
  const dec = v => v == null ? null : "stringValue" in v ? v.stringValue : "integerValue" in v ? Number(v.integerValue) : "doubleValue" in v ? v.doubleValue
    : "booleanValue" in v ? v.booleanValue : "nullValue" in v ? null : "arrayValue" in v ? (v.arrayValue.values || []).map(dec)
    : "mapValue" in v ? Object.fromEntries(Object.entries(v.mapValue.fields || {}).map(([k, x]) => [k, dec(x)])) : "timestampValue" in v ? Date.parse(v.timestampValue) : null;
  const getDoc = async name => { const r = await fetch(URL_BASE + name); if (!r.ok) return null; const j = await r.json(); return dec({ mapValue: { fields: j.fields || {} } }); };
  // نقرأ من قاعدة البيانات بس لما تنفتح خانة الطبيب، ونشارك النسخة بين التبويبات (الجدول كل 10 دقائق، حالات اليوم كل دقيقتين)
  let busy = false;
  async function load() {
    if (busy || Date.now() - lastFetch < 20000) return; busy = true; lastFetch = Date.now();
    try {
      const { sabaBoardCache: c = {} } = await chrome.storage.local.get("sabaBoardCache");
      const needB = !c.board || Date.now() - (c.at || 0) > 10 * 60000, needT = Date.now() - (c.tAt || 0) > 2 * 60000;
      const [b, t] = await Promise.all([needB ? getDoc("bawadi") : c.board, needT ? getDoc("bawadi_today") : c.today]);
      if (b?.departments) board = b; today = t || null;
      if (needB || needT) chrome.storage.local.set({ sabaBoardCache: { board: board || c.board, at: needB ? Date.now() : c.at, today, tAt: needT ? Date.now() : c.tAt } });
    } catch { /* بدون نت — نكمل بالنسخة المحفوظة */ }
    busy = false; lastSig = ""; tick();
  }

  /* ---------- مطابقة اسم أثير (الاسم الكامل | التخصص) مع جدول البوادي ---------- */
  const norm = s => String(s || "").replace(/[ً-ْـ]/g, "").replace(/[أإآٱ]/g, "ا").replace(/ى/g, "ي").replace(/ة/g, "ه").replace(/ؤ/g, "و").replace(/ئ/g, "ي").replace(/ء/g, "").replace(/[^\p{L}\p{N}\s]/gu, " ").replace(/\s+/g, " ").trim();
  const deAl = t => t.length > 4 && t.startsWith("ال") ? t.slice(2) : t;
  const toks = s => norm(s).split(" ").filter(t => t.length > 1 && !["د", "دكتور", "دكتوره", "اخصائي", "اخصائيه", "استشاري", "استشاريه"].includes(t)).map(deAl);
  // حرف زايد/ناقص/مختلف مسموح في الأسماء: نرمين ≈ نيرمين
  const lev1 = (a, b) => { if (Math.abs(a.length - b.length) > 1) return false; let i = 0, j = 0, e = 0; while (i < a.length && j < b.length) { if (a[i] === b[j]) { i++; j++; continue; } if (++e > 1) return false; if (a.length > b.length) i++; else if (b.length > a.length) j++; else { i++; j++; } } return e + (a.length - i) + (b.length - j) <= 1; };
  const near = (a, b) => a === b || (a.length >= 4 && b.length >= 4 && lev1(a, b)) || (a.length >= 5 && b.length >= 5 && (a.startsWith(b) || b.startsWith(a)));
  const docs = () => (board?.departments || []).flatMap(p => (p.doctors || []).map(d => ({ ...d, dep: p, fl: d.floor || p.floor })));
  // التخصص: «الطب الباطني» في أثير = «الباطنية» في الجدول. null = ما عرفناه (ما نحكم به)
  const SPEC = [["teeth", /اسنان|تقويم|لثه|جذور/], ["int", /باطن/], ["surg", /جراح/], ["obgyn", /نساء|ولاده/], ["peds", /اطفال/], ["cardio", /قلب/], ["ent", /انف|اذن|حنجره/],
    ["eye", /عيون|رمد/], ["psych", /نفسي/], ["uro", /مسالك|بولي/], ["ortho", /عظام/], ["pt", /علاج طبيعي|طبيعي/], ["diet", /تغذيه/], ["derm", /جلد/], ["family", /اسره/], ["gp", /عام/]];
  const specOf = s => { const x = norm(s); for (const [k, re] of SPEC) if (re.test(x)) return k; return null; };
  function matchAthir(text) {
    const [nm, sp = ""] = String(text).split("|"), full = toks(nm), spec = specOf(sp);
    if (!full.length) return null;
    const scored = docs().map(d => {
      const bt = toks(String(d.name).split(/\s*[–-]\s*/)[0]); let hit = bt.filter(t => full.some(f => near(f, t))).length, n = bt.length, first = bt[0] && near(bt[0], full[0]);
      // قوي = كل كلمات اسم الجدول موجودة في أثير بنفس الحروف (ايهاب المتولي ⊂ ايهاب محمد محمود المتولي)
      let strong = hit === n && bt.every(t => full.includes(t));
      for (const fn of [d.fullName, ...(d.aliases || [])].filter(Boolean)) {   // الاسم الكامل / أسماء ثانية: أثير يكتب أجزاء منه (وائل محمد الهجين ⊂ وائل محمد عبدالله الهجين)
        const ft = toks(fn), fh = full.filter(f => ft.some(t => near(f, t))).length, fx = full.filter(f => ft.includes(f)).length;
        if (ft[0] && near(ft[0], full[0]) && fh >= Math.min(3, full.length, ft.length) && (fh > hit || (fh === hit && !strong))) { hit = fh; n = full.length; first = true; strong = fx === full.length || fx >= 3; }
      }
      // تطابق ضعيف (حرف مختلف أو كلمة ناقصة) مع تخصص مختلف = دكتور ثاني: أشرف عوض أمين (جراحة) ≠ أشرف الأمير (طب أسرة)
      const ds = specOf(d.dep?.name), clash = spec && ds && spec !== ds;
      return [d, hit + (strong ? .5 : 0) + (spec && ds === spec ? .25 : 0), n, first && !(clash && !strong), hit];
    })
      .filter(([, , n, first, hit]) => first && (hit >= 2 || (n === 1 && hit === 1))).sort((a, b) => b[1] - a[1]);
    return scored.length && (scored.length === 1 || scored[0][1] > scored[1][1]) ? scored[0][0] : null;
  }

  /* ---------- حالة الطبيب الحين (نفس منطق صفحة الأطباء) ---------- */
  function nowR() {
    const p = Object.fromEntries(new Intl.DateTimeFormat("en-GB", { timeZone: "Asia/Riyadh", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23", weekday: "short" }).formatToParts(new Date()).map(x => [x.type, x.value]));
    return { m: +p.hour * 60 + +p.minute, wd: { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 }[p.weekday], iso: `${p.year}-${p.month}-${p.day}` };
  }
  const hm = m => { const h = Math.floor(m / 60) % 24, mi = m % 60; return `${h % 12 || 12}${mi ? ":" + String(mi).padStart(2, "0") : ""}${h < 12 ? "ص" : "م"}`; };
  const shiftsFor = (d, wd) => d.alt?.days?.includes(wd) ? (d.alt.shifts || []) : (d.shifts || []);
  function active(d, t) {
    if ((d.workdays || []).includes(t.wd)) for (const s of shiftsFor(d, t.wd)) if (s.e > s.s ? (t.m >= s.s && t.m < s.e) : t.m >= s.s) return s;
    const y = (t.wd + 6) % 7; if ((d.workdays || []).includes(y)) for (const s of shiftsFor(d, y)) if (s.e <= s.s && t.m < s.e) return s;
    return null;
  }
  // «بعد ساعة و20 دقيقة»
  const left = mins => { mins = Math.max(1, Math.round(mins)); const h = Math.floor(mins / 60), m = mins % 60;
    const H = h === 1 ? "ساعة" : h === 2 ? "ساعتين" : h <= 10 ? `${h} ساعات` : `${h} ساعة`, M = m === 1 ? "دقيقة" : m === 2 ? "دقيقتين" : m <= 10 ? `${m} دقائق` : `${m} دقيقة`;
    return h && m ? `${H} و${M}` : h ? H : M; };
  const isoAdd = (iso, n) => { const x = new Date(iso + "T12:00:00Z"); x.setUTCDate(x.getUTCDate() + n); return x.toISOString().slice(0, 10); };
  // أقرب بداية دوام (اليوم أو الأيام الجاية، ونتخطى أيام الإجازة)
  function nextStart(d, t) {
    for (let i = 0; i < 8; i++) {
      const wd = (t.wd + i) % 7, iso = isoAdd(t.iso, i);
      if (!(d.workdays || []).includes(wd)) continue;
      if ((board.vacations || []).some(v => v.doctorId === d.id && v.start <= iso && (!v.end || v.end >= iso))) continue;
      const st = shiftsFor(d, wd).map(x => x.s).filter(x => i > 0 || x > t.m).sort((a, b) => a - b)[0];
      if (st != null) return { day: i, wd, s: st, mins: i * 1440 + st - t.m };
    }
    return null;
  }
  function whenTxt(n) {
    if (!n) return "خارج الدوام";
    if (n.day === 0) return `دوامه يبدأ ${hm(n.s)} — بعد ${left(n.mins)}`;
    return `دوامه ${n.day === 1 ? "بكرة" : WD[n.wd]} ${hm(n.s)}`;
  }
  // إجازة جاية خلال أسبوع: عدّ تنازلي بالأيام («إجازة بعد 3 أيام — من السبت 7/11»)
  function soonVac(d) {
    const t = nowR();
    const v = (board.vacations || []).filter(v => v.doctorId === d.id && v.start > t.iso).sort((a, b) => a.start < b.start ? -1 : 1)[0];
    if (!v) return "";
    const days = Math.round((Date.parse(v.start + "T12:00:00Z") - Date.parse(t.iso + "T12:00:00Z")) / 864e5);
    if (days < 1 || days > 7) return "";
    const wd = WD[new Date(v.start + "T12:00:00Z").getUTCDay()], dm = v.start.slice(8, 10) + "/" + v.start.slice(5, 7);
    return `🏖 إجازة ${days === 1 ? "بكرة" : days === 2 ? "بعد يومين" : `بعد ${days} أيام`} — من ${wd} ${dm}${v.end ? " لين " + v.end.slice(8, 10) + "/" + v.end.slice(5, 7) : ""}`;
  }
  function status(d) {
    const t = nowR();
    const vac = (board.vacations || []).find(v => v.doctorId === d.id && v.start <= t.iso && (!v.end || v.end >= t.iso));
    if (vac) { const n = vac.end ? nextStart(d, t) : null; return ["vac", `في إجازة${vac.end ? " لين " + vac.end.split("-").reverse().slice(0, 2).join("/") : ""}${n && n.day > 0 ? " · يرجع " + (n.day === 1 ? "بكرة" : WD[n.wd]) + " " + hm(n.s) : ""}`]; }
    const s = today?.date === t.iso ? today.st?.[d.id] : null, a = active(d, t);
    if (s?.kind === "stop") return ["red", "⛔ وقف استقبال الحالات"];
    if (s?.kind === "absent" && s.off) return ["gray", "خلص دوامه اليوم"];               // دوام اليوم المعدّل خلص (أو طلع بدري)
    if (s?.kind === "absent") return ["red", "غير متواجد اليوم"];
    if (s?.kind === "appt") {                                              // مواعيد فقط + متى يخلص دوامه
      const end = s.until ?? (a ? a.e : null);
      if (s.until != null && t.m >= s.until) return ["gray", "خلص دوامه اليوم"];
      return ["amber", `مواعيد فقط${end != null ? " — لين " + hm(end) + (end - t.m <= 60 && end > t.m ? ` (باقي ${left(end - t.m)})` : "") : ""}`];
    }
    if (s?.kind === "absent" && s.off) return ["gray", "خلص دوامه اليوم"];
    if (s?.kind === "absent") return ["red", "غير متواجد اليوم"];
    const walkTxt = () => s.apptFrom != null ? (t.m < s.apptFrom ? ` · انتظار لين ${hm(s.apptFrom)}` : " · مواعيد فقط") : "";
    if (s?.kind === "late" && t.m < s.from) return ["amber", `متأخر — يوصل ${hm(s.from)} (بعد ${left(s.from - t.m)})${s.apptFrom != null ? ` · انتظار لين ${hm(s.apptFrom)}` : ""}`];
    if (s?.kind === "late" && s.apptFrom != null) return [t.m >= s.apptFrom ? "amber" : "green", `✓ متواجد الحين${a ? " — لين " + hm(a.e) : ""}${walkTxt()}`];
    if (s?.kind === "busy") return ["amber", `زحمة${s.count ? " — " + s.count + " بالانتظار" : ""}`];
    // دوام اليوم بس (من القروب): «اليوم من 2م إلى 7م» + «انتظار لين 5م»
    if (s?.kind === "starts" && s.from != null) {
      const end = s.until ?? null;
      if (t.m < s.from) return ["amber", `اليوم يبدأ ${hm(s.from)} — بعد ${left(s.from - t.m)}`];
      if (end != null && t.m >= end) return ["gray", "خلص دوامه اليوم"];
      const walk = s.apptFrom != null ? (t.m < s.apptFrom ? ` · انتظار لين ${hm(s.apptFrom)}` : " · مواعيد فقط") : "";
      return [s.apptFrom != null && t.m >= s.apptFrom ? "amber" : "green", `✓ متواجد الحين${end != null ? " — لين " + hm(end) : ""}${walk}`];
    }
    if (s?.kind === "appt_at") return ["amber", t.m < s.from ? `انتظار لين ${hm(s.from)} · بعدها مواعيد فقط` : "مواعيد فقط"];
    if (s?.kind === "leaves" && s.until != null) return t.m >= s.until ? ["gray", "خلص دوامه اليوم"] : ["green", `✓ متواجد الحين — اليوم لين ${hm(s.until)}${s.until - t.m <= 60 ? ` (باقي ${left(s.until - t.m)})` : ""}`];
    if ((s?.kind === "free" || s?.kind === "present") && s.until != null) return t.m >= s.until ? ["gray", "خلص دوامه اليوم"] : ["green", `✓ متواجد الحين — لين ${hm(s.until)}`];
    if (s?.kind === "free" || s?.kind === "present") return ["green", "متواجد الحين"];
    if (a) { const endIn = (a.e > a.s ? a.e : a.e + (t.m >= a.s ? 1440 : 0)) - t.m; return ["green", `✓ متواجد الحين — لين ${hm(a.e)}${endIn <= 60 ? ` (باقي ${left(endIn)})` : ""}`]; }
    const n = nextStart(d, t);
    return [n && n.day === 0 && n.mins <= 60 ? "amber" : "gray", whenTxt(n)];
  }

  /* ---------- (1.9.9) خط أحمر على الطبيب اللي ما يستقبل الحين ---------- */
  // إجازة، غير متواجد، وقف استقبال، زحمة، مواعيد فقط، خلص دوامه، اليوم مو من أيامه، أو دوامه يبدأ بعد أكثر من ساعة.
  // يرجّع السبب (أو "" = عادي). الموظف يقدر يختاره عادي — الخط تنبيه بس.
  const dmy = iso => iso.slice(8, 10) + "/" + iso.slice(5, 7);
  function strike(d) {
    const t = nowR();
    const vac = (board.vacations || []).find(v => v.doctorId === d.id && v.start <= t.iso && (!v.end || v.end >= t.iso));
    if (vac) return `إجازة${vac.end ? " لين " + dmy(vac.end) : ""}`;
    const s = today?.date === t.iso ? today.st?.[d.id] : null, a = active(d, t);
    if (s) {
      if (s.kind === "stop" || (s.kind === "stop_at" && s.from != null && t.m >= s.from)) return "وقف استقبال";
      if (s.kind === "absent") return s.off ? "خلص دوامه اليوم" : "غير متواجد اليوم";
      if (s.kind === "busy") return "زحمة — عنده انتظار";
      if (s.kind === "appt") return s.until != null && t.m >= s.until ? "خلص دوامه اليوم" : "مواعيد فقط";
      if (s.kind === "appt_at" && s.from != null && t.m >= s.from) return "مواعيد فقط";
      if (s.apptFrom != null && t.m >= s.apptFrom) return "مواعيد فقط";
      if (s.kind === "late" && s.from != null && s.from - t.m > 60) return `متأخر — يوصل ${hm(s.from)}`;
      if (s.kind === "starts" && s.from != null) return s.from - t.m > 60 ? `دوامه اليوم يبدأ ${hm(s.from)}` : s.until != null && t.m >= s.until ? "خلص دوامه اليوم" : "";
      if (["leaves", "free", "present"].includes(s.kind) && s.until != null && t.m >= s.until) return "خلص دوامه اليوم";
      if (["free", "present", "late", "leaves", "appt_at", "stop_at"].includes(s.kind)) return "";
    }
    if (a) return "";
    if (!(d.workdays || []).includes(t.wd)) return "اليوم مو من أيام دوامه";
    const n = nextStart(d, t);
    if (n && n.day === 0) return n.mins > 60 ? `دوامه يبدأ ${hm(n.s)} — بعد ${left(n.mins)}` : "";
    return (shiftsFor(d, t.wd) || []).length ? "خلص دوامه اليوم" : "اليوم مو من أيام دوامه";
  }
  const whyCache = new Map(); let whyKey = "";
  function whyOf(text) {
    const t = nowR(), k = t.iso + t.m + (today?.date || "") + JSON.stringify(today?.st || {}).length + (board?.updatedAt || "");
    if (k !== whyKey) { whyCache.clear(); whyKey = k; }
    if (!whyCache.has(text)) { const d = board ? matchAthir(text) : null; whyCache.set(text, d ? strike(d) : ""); }
    return whyCache.get(text);
  }
  function paint(el, why) {
    if (!el) return;
    if ((el.dataset.sabaWhy || "") === why) return;
    el.dataset.sabaWhy = why;
    const st = el.style;
    if (why) { st.textDecoration = "line-through"; st.textDecorationColor = "#D92D20"; st.textDecorationThickness = "2px"; st.color = "#8A94A6"; el.title = "⛔ " + why; }
    else { st.textDecoration = ""; st.textDecorationColor = ""; st.textDecorationThickness = ""; st.color = ""; if (/^⛔ /.test(el.title || "")) el.title = ""; }
  }
  // الاسم في الخانة بعد ما ينختار (select2 / chosen / select عادي)
  function paintSelected(why) {
    const nx = field.nextElementSibling;
    const shown = nx?.querySelector?.(".select2-selection__rendered, .chosen-single > span") || null;
    paint(shown || field, why);
  }
  // القائمة لما تنفتح: كل اسم عليه خط + السبب صغير جنبه
  function paintList() {
    if (!board) return;
    for (const li of document.querySelectorAll(".select2-results__option, .chosen-results li, .select2-results li")) {
      const tag = li.querySelector(":scope > .saba-why"), txt = (li.firstChild?.nodeType === 3 ? li.textContent.replace(tag?.textContent || "", "") : li.textContent.replace(tag?.textContent || "", "")).trim();
      if (!/\|/.test(txt)) continue;
      const why = whyOf(txt);
      if ((li.dataset.sabaWhy || "") === why && (!why || tag)) continue;
      paint(li, why);
      tag?.remove();
      if (why) { const sp = document.createElement("span"); sp.className = "saba-why"; sp.textContent = "  ⛔ " + why; sp.style.cssText = "display:inline-block;text-decoration:none;color:#B4232A;font-size:11.5px;font-weight:600;margin-inline-start:8px;background:#FDECEC;border-radius:6px;padding:0 6px"; li.append(sp); }
    }
    if (field) for (const o of field.options) { if (!/\|/.test(o.text)) continue; const why = whyOf(o.text.trim()); o.style.color = why ? "#B4232A" : ""; o.title = why ? "⛔ " + why : ""; }
  }

  /* ---------- البطاقة جنب خانة الطبيب ---------- */
  function ensureBox() {
    if (host && document.documentElement.contains(host)) return;
    document.getElementById("saba-athir-doc")?.remove();
    host = document.createElement("div"); host.id = "saba-athir-doc";
    host.style.cssText = "all:initial;position:fixed;z-index:2147483646;display:none";
    const root = host.attachShadow({ mode: "open" });
    const CSS = `.b{direction:rtl;font-family:"IBM Plex Sans Arabic","Segoe UI",Tahoma,sans-serif;background:#fff;border:1px solid #DCEBF4;border-inline-start:5px solid #00A6E2;border-radius:12px;padding:7px 12px;box-shadow:0 8px 22px -12px rgba(0,55,101,.45);display:grid;gap:3px;min-width:220px;max-width:340px;text-align:right}
      .r1{display:flex;gap:8px;align-items:center;font-size:14px;font-weight:700;color:#003765;flex-wrap:wrap}
      .r1 span{background:#EAF6FC;border-radius:8px;padding:1px 8px}
      .r2{font-size:12.5px;font-weight:600}.r3{font-size:12px;color:#9A5B00;background:#FFF4E5;border-radius:6px;padding:2px 6px;margin-top:2px}.green{color:#0A7A55}.red{color:#B4232A}.amber,.vac{color:#9A5B00}.gray{color:#5B7690}
      .no{font-size:12.5px;color:#5B7690}`;
    try { const sh = new CSSStyleSheet(); sh.replaceSync(CSS); root.adoptedStyleSheets = [sh]; root.innerHTML = '<div class="b"></div>'; } catch { root.innerHTML = `<style>${CSS}</style><div class="b"></div>`; }
    box = root.querySelector(".b");
    document.documentElement.append(host);
  }
  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  function place() {
    if (!host || host.style.display === "none" || !field) return;
    const vis = field.offsetParent ? field : (field.nextElementSibling?.classList?.contains("select2") || field.nextElementSibling?.className?.includes?.("chosen") ? field.nextElementSibling : field.parentElement);
    const r = (vis || field).getBoundingClientRect();
    if (!r.width) { host.style.display = "none"; return; }
    const w = host.offsetWidth || 260;
    host.style.top = Math.max(4, r.top + r.height / 2 - (host.offsetHeight || 50) / 2) + "px";
    host.style.left = Math.max(4, r.left - w - 12) + "px";               // يسار الخانة (الصفحة عربية)
  }

  // خانة الطبيب: select عنوانها «الطبيب» أو خياراتها «الاسم | التخصص»
  function findField() {
    const sels = [...document.querySelectorAll("select")];
    const byOpts = sels.filter(s => [...s.options].filter(o => /\|/.test(o.text)).length >= 2);
    return byOpts[0] || null;
  }
  function tick() {
    field = findField();
    if (!field) { if (host) host.style.display = "none"; return; }
    if (!board) load();
    try { paintList(); } catch { /* شكل قائمة غريب — البطاقة تكمل */ }
    const o = field.options[field.selectedIndex], txt = o && o.value && !/اختر/.test(o.text) ? o.text.trim() : "";
    try { paintSelected(txt && board ? whyOf(txt) : ""); } catch {}
    if (!txt) { if (host) host.style.display = "none"; lastSig = ""; return; }
    if (!board) return;
    const t = nowR(), sig = txt + "|" + t.m + "|" + (today?.date || "") + (board?.updatedAt || "");
    if (sig !== lastSig) {
      lastSig = sig; ensureBox();
      const d = matchAthir(txt);
      if (!d) box.innerHTML = `<div class="no">د. ${esc(txt.split("|")[0].trim())} — مو موجود في جدول البوادي</div>`;
      else {
        const fl = board.floorNames?.[d.fl] || FLOOR_DEF[d.fl] || "الدور " + d.fl, [cls, st] = status(d);
        box.innerHTML = `<div class="r1"><span>${esc(fl)}</span>${d.room ? `<span>عيادة ${esc(d.room)}</span>` : ""}${d.ext ? `<span>☎ ${esc(d.ext)}</span>` : ""}</div><div class="r2 ${cls}">${esc(st)}</div>${(() => { const sv = soonVac(d); return sv ? `<div class="r3">${esc(sv)}</div>` : ""; })()}`;
      }
      host.style.display = "block";
    }
    place();
  }
  const alive = () => { try { return !!chrome.runtime?.id; } catch { return false; } };
  const iv = setInterval(() => { if (!alive()) { clearInterval(iv); return; } if (document.visibilityState === "visible") tick(); }, 500);       // select2 ما يطلق change عادي، فنراقب القيمة
  addEventListener("scroll", place, true); addEventListener("resize", place);
  setInterval(() => { if (field && document.visibilityState === "visible") load(); }, 60000);
  // الخلفية تشيك كل 30 ثانية: أي تعديل (من القروب أو صفحة الأطباء أو زر الطبيب) يتحدث في البطاقة على طول بدون ما تعيد اختيار الطبيب
  try {
    chrome.storage.onChanged.addListener((ch, area) => {
      const c = area === "local" && ch.sabaBoardCache?.newValue; if (!c || !alive()) return;
      if (c.board?.departments) board = c.board;
      if (c.today !== undefined) today = c.today || null;
      lastSig = ""; tick();
    });
  } catch { /* سياق الإضافة انتهى */ }
})();
